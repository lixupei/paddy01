clc;clear;
SP=xlsread('F:\��Ȩ����\garch���Ĵ���\SP500.xlsx');
SP=SP(8515:20600,4);
% SP=SP(20000:20300,4);
R=100*diff(log(SP));
para=[0.506 0.00588 -0.000116 -0.0529 0.926 0.53 0.00000223 0.000811 132 0.00286 0.0119 4.74 0.0984 0.105 -0.0175 0.00978];
% H0=[0.0336 0.1]
% options = optimset('Display','iter','MaxIter',1000,'TolFun',1e-6,'TolX',1e-6);
% [theta_NMLE, fobj, exitflag, output1]= fminsearchbnd('Garch_MLE',para, [], [], options,R);
% x = fminsearch(@Garch_MLE,para,R)
options = optimoptions('fminunc','TolX',1e-15,'MaxFunEvals',1e5,'MaxIter',1e5,...
    'Display','iter-detailed','Algorithm','quasi-newton');
[x,fval,exitflag,output,grad,hessian] = fminunc(@filter_loglike,para,options,R)
% info.method = 'bfgs'; 
% result = maxlik('filter_loglike',para,info,R);
% options = optimset('Display','iter','FunValCheck','on','TolX',1e-15,'MaxFunEvals',1e5,'MaxIter',1e5);
% [x,fval,exitflag,output] = fminsearch(@filter_loglike,para,options,R);
% A=zeros(16,16);A(3,3)=1;A(4,4)=1;b=zeros(16,1);b(3:4,1)=1;
% options = optimoptions('fmincon','SpecifyObjectiveGradient',true)
% [x,fval,exitflag,output,lambda,grad,hessian] = fmincon(@filter_loglike,para,A,b,[],[],[],[],[],options,R);
