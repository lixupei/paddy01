function LL = filter_loglike(para,data)
rng default
R=data;
r=mean(R);Loglike(1)=0;
lambda_z=para(1);lambda_y=para(2);w_z=para(3);w_y=para(4);b_z=para(5);
b_y=para(6);a_z=para(7);a_y=para(8);c_z=para(9);c_y=para(10);
d_z=para(11);d_y=para(12);e_z=para(13);e_y=para(14);theta=para(15);delta=para(16);
H_y(1)=0.0336;  H_z(1)=0.1;
% b_z=(exp(b_z)-1)/(exp(b_z)+1);
% b_y=(exp(b_y)-1)/(exp(b_y)+1);
% syms y z
% equ1=z==w_z+b_z*z+a_z+a_z*c_z^2*z-2*d_z*e_z*theta*y+d_z*e_z^2+d_z*(delta^2+theta^2)*y+d_z*theta^2*y^2;
% equ2=y==w_y+b_y*y+a_y+a_y*c_y^2*z-2*d_y*e_y*theta*y+d_y*e_y^2+d_y*(delta^2+theta^2)*y+d_y*theta^2*y^2;
% equs=[equ1 equ2];
% S = solve(equs,[z y]);
% H_y(1)=min(double(S.y)); H_z(1)=min(double(S.z));
for t=1:length(R)-1
    mu(t)=r+(lambda_z-0.5)*H_z(t)+(lambda_y-(exp(theta+0.5*delta^2)-1))*H_y(t);     %�����ʵľ�ֵ
    for j=0:50
        Pr_p(j+1,t)=poisspdf(j,H_y(t));  %tʱ��Ԥ��t+1ʱ�̷�����Ծj�εĸ��� ��45ʽ��
        f_RCon(j+1,t)=normpdf(R(t),(mu(t)+j*theta),sqrt(H_z(t)+j*delta^2));  %��tʱ�̣���֪t+1ʱ�̻ᷢ��j����Ծ����t+1ʱ�̵�������   ��44ʽ��   
        f_RR(j+1,t)=f_RCon(j+1,t)*Pr_p(j+1,t); %��44ʽ��45ʽ��������
    end
    f_R(t)=sum(f_RR(:,t));
    for j=0:50
        if f_R(t)==0
            Pr(1,t)=1;
            Pr(2:50,t)=0;
        else
            Pr(j+1,t)=(f_RCon(j+1,t)*Pr_p(j+1,t))/f_R(t);
        end
        Z(j+1,t)=(H_z(t)/(H_z(t)+j*delta^2))*(R(t)-mu(t)-j*theta)*Pr(j+1,t);
    end
        Z_hat(t)=sum(Z(:,t));
        y_hat(t)=R(t)-mu(t)-Z_hat(t);
    H_z(t+1)=w_z+b_z*H_z(t)+a_z/H_z(t)*(Z_hat(t)-c_z*H_z(t))^2+d_z*( y_hat(t)-e_z)^2;
    H_z(t+1)=max(10^(-20),H_z(t+1));
    H_y(t+1)=w_y+b_y*H_y(t)+a_y/H_z(t)*(Z_hat(t)-c_y*H_z(t))^2+d_y*( y_hat(t)-e_y)^2;
    H_y(t+1)=max(10^(-20),H_y(t+1));
    mu(t+1)=r+(lambda_z-0.5)*H_z(t+1)+(lambda_y-(exp(theta+0.5*delta^2)-1))*H_y(t+1);     %�����ʵľ�ֵ
    for j=0:50
        like(j+1,t+1)=normpdf(R(t+1),(mu(t+1)+j*theta),sqrt(H_z(t+1)+j*delta^2))*poisspdf(j,H_y(t+1));
        if isnan(sum(like(j+1,t+1)))==1
            like(j+1,t+1)=0;
        end
   end
    if sum(like(:,t+1))==0
        Loglike(t+1)=0;
    else
        Loglike(t+1)=log(sum(like(:,t+1)));
    end
end
% H0=[mean(H_y) mean(H_z)];
% save('output.txt','H0','-ascii');
LL=abs(sum(Loglike));
% LL(2:3)=[mean(H_y) mean(H_z)]
end